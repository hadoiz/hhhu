routes = [
  {
    path: '/',
    url: '/store/',
  },
  {
    path: '/:id/',
    url: '/cat/{{id}}',
  },
  {
    path: '/appdown/:id',
    url: '/appdown/{{id}}',
  },
  // Default route (404 page). MUST BE THE LAST
  {
    path: '(.*)',
    url: './pages/404.html',
  },
];
