<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Data extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('data', function (Blueprint $table) {
            $table->bigIncrements('id')->unsigned();
            $table->string('Category');
            $table->string('AppName');
            $table->text('Link'); 
            $table->text('AppLink'); 
            $table->text('AppIcon');
            $table->text('AppDescription');
            $table->string('AppVersion');
            $table->string('AppSize');
		    $table->timestamps();
            });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
       Schema::dropIfExists('data');
    }
}
