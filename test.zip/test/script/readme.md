
## Change Password Laravel

Biolerplate code to enable change current password on top of Laravel Basic Authentication.