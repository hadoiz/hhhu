<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Data;
use Storage;

class DataController extends Controller
{
    public function download($ipa=null,$app=null) 
    {
        header('Content-Type: text/xml;charset=UTF-8');

$z = base64_decode($ipa) ;
$x = urldecode ($app);
$c = config('app.name');
        
$input = <<<END
<?xml version="1.0" encoding="UTF-8"?>
						<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
						<plist version="1.0">
						<dict>
						   <key>items</key>
						   <array>
						       <dict>
						           <key>assets</key>
						           <array>
						               <dict>
						                   <key>kind</key>
						                   <string>software-package</string>
						                   <key>url</key>
						                   <string>{$z}</string>
						               </dict>
						               <dict>
						                   <key>kind</key>
						                   <string>display-image</string>
						                   <key>needs-shine</key>
						                   <true/>
						                   <key>url</key>
						                   <string>https://i.imgur.com/3WYFVmD.png</string>
						                </dict>
										<dict>
										<key>kind</key>
										<string>full-size-image</string>
										<key>needs-shine</key>
										<true/>
										<key>url</key>
										<string>https://i.imgur.com/3WYFVmD.png</string>
										</dict>
						           </array>
						           <key>metadata</key>
						           <dict>
						               <key>bundle-identifier</key>
						               <string>com.i3rby.{$x}</string>
						               <key>bundle-version</key>
						               <string>1.3.5</string>
						               <key>kind</key>
						               <string>software</string>
						               <key>title</key>
									   <string>   
									   
⚡{$x}⚡
⚡{$c}⚡
 			  </string>

						           </dict>
						       </dict>
						   </array>
						</dict>
						</plist>
END;

return $input;


    }
    
    public function appsList($id){
        $data=Data::select('id','AppName','AppLink','AppIcon','AppDescription','AppVersion','AppSize')->where('Category', $id)->orderBy('AppName', 'asc')->get();
        $arr=Array('data' => $data);
        return view('appsList',$arr);
    }
    
     public function installconfig(){
     $c = config('app.name');

        $input = <<<END
        <?xml version='1.0' encoding='UTF-8'?>
        <!DOCTYPE plist PUBLIC '-//Apple//DTD PLIST 1.0//EN' 'http://www.apple.com/DTDs/PropertyList-1.0.dtd'>
        <plist version='1.0'>
        <dict>
            <key>PayloadContent</key>
            <array>
                <dict>
                    <key>FullScreen</key>
                    <true/>
                    <key>Icon</key>
                    <data>
              /9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxINEA4NDxARDxAQFxIPEBAODQ8RFhAOFREWFxURExcYHiggGholGxUVITEhJSkrLy4uFyAzODMtNyktLisBCgoKDQ0OGxAQGisiICUvLS4uLSstLS0tLTArLSstNy0vLS03LS0tLS0rLS0rLS0tLSstLS8tLS0tLSstLS8tLf/AABEIAN8A4gMBEQACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABQcBAgYDBP/EAD0QAAIBAgEGCgoBAwUBAAAAAAABAgMRBAUGITFxsRIUIjJBUVJhcpMTFjRCU4GRobLhIwdiwTOCotHwJP/EABsBAQACAwEBAAAAAAAAAAAAAAAFBgEDBAIH/8QAMxEBAAEDAQQJAwQCAwEAAAAAAAECAwQRBRIhMRMVMjNBUWFxkRQiNFKBobEG0SNDwUL/2gAMAwEAAhEDEQA/ALxAARWWcu0sJyX/ACVWrqlB6bdcn7qN9mxXdnhyR2dtOxiR986z5OQx+W6+Ib4VR04fDotxXzlre7uJO1iW6OfGVOzNuZV+dKZ3Y8o/2jYwS1JLYjq0hDTMzzbGWAAAAAAAAAAAAAAAAAAAAMNJ69O0wzGsPowWOq4f/RqSguxzoP8A2vR9LGm5j26+cJDF2plY3Yq4eU8nV5HzphVap10qNR6FK/Im+pP3X3P6kbexKqOMcYW7Z+3LOT9lf21fxLojjToAAAc/nNl7i/8ABRs60ldvWqUX7z/u6l89vXjY3STrPJCbX2rGJTuUduf4cVe7cm3KUneUpO7k+tsmKaYpjSFDu3K7tU11zrMh6awAAAAAAAAAAAAAAAAAAAAAAAAw1fQ9KDMcHQ5tZfdFxw9eV6TtGnUk9NN9EJPs9T6N0blYv/3QtmxtszrFi/PtP/jtSMW4A+DLeUlhKM6r0y5tOPaqPUtnS+5M2Wrc3K4phyZuVTjWZuT+3uriUnJynN8Kcm5Sk+mT6SfopimNIfNb96u9XNdc6zIemoAAAAAAAAAAAAAAAAAAAAAAAAAADDV9D1MMxwdpmdlV1YPDVHepSS4Lb0zpak33rU/kQ2ZY3KtY5Svuw9ofUWtyvtU/zDozjTjhM88b6XEKinyaC0rrqzSb+kbfVktgW9Kd/wA1L/yPK3rsWY5Rz95QRIK0AAAAAAAAAAAD2w+GnVdqcXN9yPFddNHGqW6zj3b06W6ZlKUc2MRLTaMfFI5qs21CVt/4/mVRrMRHvLeeauIWlcB7JGIzrXq9Vf47mRHDSf3RmLydVo/6kJRXXbR9ToovUV9mUbkYORY7ymYfKbXIAAAAAAAAAAAD3yfjOLVqWI6IPl99N6JL6afkjRkW+ktzDv2ZlTjZNNfh4+y0UyAfSlU16/pp1K3xJzn8nJ2+1iw2aN2iIfMc6702RXX5y0NrlAAAAAAAAAADosgZuutarWvGn0R6Zf8ASODJy9z7aOaxbL2JN6Iu3uFPl5pnGZaw+CXoqcVKS92GpbWclGNdvfdUmcjaeHgx0duNZjwhCVs7az5kYQXeuEdlOBbjnKFuf5Hk1diIj+WtPOuutfAkvDYzOBa8Hij/ACLLieOk/slsDnTSq8itH0d9F3pj8+o5bmDXRxonVL4u37F77b0bv8w88s5txqRdbDWT18FapbOo9WMyqmd241bR2Hbu09LjcJ8vCXISi02mrNaGn0MlInWNVQqpmmdJ5sGWAAAAAAAAABhq+jr0Ajg6LB55Qp06VOV+FCMYS0e8opPoIivFmapXaztiiLdMTz0j+nNUlaMV3LcS8clLq5y2DAAAAAAAAAAmM2cmcZq3lzIcqXe+hHLl3ujo4c5S+xsD6m9rV2aeM/6TWdOWvRf/ADUXZ25TXurqRyYmNv8A31JnbW05sx0FnhPjPl6OObJVT2AAACezay26ElSm70paNPuPrXccWXjRXG9TzT2x9qVWK4tXJ+2f4fdnjkxK2KgteidvtI04N7/rn9nZt/AjT6iiPf8A25Mk1VAAAAAAAAAACPq0uVLa95rmOLqpq4Q+5GxzMmQAAAAAwPaOEqPSqc2u6Ejz0lHnDdGNenjFE/Es8Sq/CqeXIx0lHnDP0t/9FXxJxKr8Kp5ch0lHnB9Lf/RV8S7bNjDOhhXNxanLhSatp7kRGXXFd3TXguex7E4+HvTHGdZcbiaFapOVR06l5NvmS6SVoqt00xETCoXrWRduTXNFXGfKXnxKr8Kp5cj10lHnDX9Lf/RV8ScSq/CqeXIdJR5wfS3/ANFXxJxKr8Kp5ch0lHnB9Lf/AEVfEnEqvwqnlyHSUecH0t/9FXxJxKr8Kp5ch0lHnB9Lf/RV8S7nJsZYjBejqxalwXBqSs3bUyHuzFu/rSu2JFWRgbl2J10mOPo4eWBqpteino0cyRMRdo84UqcS/E6bk/EscSq/CqeXIdJR5wx9Lf8A0VfEnE6vwqnlyHSUecH0t/8ARV8S8ZRadmmn1NWPcTE8mmqmaZ0mNGDLAAAAAAHk4nnR6iW9z08lwFwFwFwFwOuzPyPGceM1EpabQT1eIi83ImJ3KVr2Fs2iqnp7ka+X+3XpWIxaoiIZDIAAAAAAAAAAAAACGzhyPDEU5SSSqRTlGSWu3Qzqxsiq3Vp4InamzreTamYjSqOUq7ejQTigTGk6MXMsFwFwFwFwAZYAAAAAABZGavstHY95A5fey+hbH/DoS5zJMAAAAAAAAAAAAAAA0q6nse4zHNirlKpq/Pn4pb2WSjsw+YXu8q95aHpqAAAAAA1DIAAAAFwLKzU9ko7HvIHL72X0HY/4lCXOZJgAAAAAAAAAAAAAAGtXU9j3GY5sVclSYh8ufilvZZKOzD5je7yr3l5npqAAAAAAwZZAAAAAuBZWanslHZ/kgMvvZfQNkfiUJg5kmAAAAAAAist5cp4NLhcqb5sFr2vqR0WMeq7PDkj87aNrEp+7jPhD582cszxnpXOMYxjZRtfpvrPeVj02dIiWjZe0LmZvTVGkRyTpyJcAAAAGtXU9j3GY5sVclR4h8ufilvZZaOzD5le7yr3l5npqAAAAAA1uGS4C4C4C4GQLLzT9ko7HvIDL76V/2R+JQmDmSYAAAAAGJOybDEyq/FKrjcTUcYucnJpa7RinZbET9E0WbUaqBfi9m5NW7Gs66ezv8g5MWEoxp65PTN9ciHyL03a95ctn4cYtmKPHxSRodwAAAANKup7HuMxzYq5KixHPn4pb2WWjsw+Z3u8q95edz01FwFwFwFwFwMBkAAAAACzc0vZKOx7yAy++lf8AZH4lCYOZJAAABEZwZbjgoLRwqkubC/3fcdGPj1XZ9EdtDaFGJRrPGZ5Q4bFZxYmq23VcV2YaEiXoxLVMclSu7Wy7k672ns98FnViKWiUlVXVNafqeLmFaq5cG2xtvKt9qd6PVnFZ1Vp6KajRT7CTf1MUYVEdqdXq9tu/VwtxFPtzfDHLWIT4SrTvtN041rluuONo5cTrFcuqzYzmlXmqFZXk+bOK3oj8rDiiN+lYdlbXrv19Fdjj4TDrCOWIAAANKup7HuMxzYq5KhxHPn4pb2WWjsw+aXu8q95eZ6agAAAAANbmWS4C4C4C4C4FnZo+yUdj3lfzO+lftkfiUJk5kkAAAFVZxYx18TVk3oTcI9yjoLDi24otw+f7Tvzeyapnw4fCNudCPLgLgLmGVl5qZKjh6MZtfyVFwpPciCy703K9PCF62ThU2LMTp90804ciVAAADSrqex7jMc2KuSn8Q+XPxS/Jllo7MPmt7vKveXnc9tRcBcBcBcBcDFwyXAXAXAXAXAs/NH2Sjse8r+Z30r7sn8ShMnMkgABrNaH8wxPJUGOVqtVPtz/Jllt9iPZ84yY0vV+8/wBvC5saC4C4C4FvZLrKpRpTjqcUVq7TNNcxL6RjVxXapqjxh9RrbwAAA0q817HuMxzYq5KexD5c/FL8mWajsw+a3u8q95edz01lwFwFwFwFwNbhkuAuAuAuAuBaGaHsdHY95X8zvpXzZP4lCaOZJAAABVudmE9Diqq6J8tfPX9yfw69+1Hoom1rHRZNXlPFD3OpGFwFwAZdLmtnI8NahUTlTb5NtcW/8HBl4kXPup5pvZW1Jsf8VfGnw9FiJ30kKuUMgAAGlXmvY9xmObFXJTmIfLn4pfkyzUdmHza73lXvLzuemsuAuAuAuAuBrcMlwFwFwFwFwLSzP9jo7HvK/md9K+bJ/EoTRzJEAAAOaz2yQ8RSVaCvOlpt1w6Ud2Df3K92eUoXbOFN61v086f6Vxcm1NLhguAA6LMzJTxFZVZL+OlpffLoRxZt7co3Y5ymdj4c3r2/PKn+1lEGugAAAaVebLY9xmObFXJTWI58/FL8mWajsw+b3e8q95edz01lwFwFwFwFwNTL0AAAABcC08zvY6Gx7yv5nfSvWyfxaU2cqRAAAA0BxWcGZrnN1cM0uFpdN6NPWmSmPnxTG7WrefsWa65rs+Pg+bAZizlprVFBdUFd/U93No0x2YabGwK543atPZ9WLzDjb+KtJS/vSt9jXRtKdfuhvu/4/Rp/x1zr6o7D5kV3O05RjDpknfR3I31bQt6cI4uOjYN+atKpiId3k3AQw1ONKmrJfd9bIm5cquVb1S0Y+PRYtxRRHB9RrbwAAA0q82Wx7jMc2KuSmMS+XPxS/Jlno7MPnN3t1e8vM9NYAAAAAGLhkuAuAuAuAuBamZ3sdDY95X8zvpXnZX4tKbOVIgAAAAAAAAAAAAAAGlXmy2PcZjmxVyUviXy5+KX5Ms9HZh85u9ufeXnc9PBcBcBcBcBcDW4ZLgLgLgLgLgWtmb7HQ2PeV/M76V42V+LSmzlSIAAAAAAAAAAAAAABpV5stj3GY5sVclK4l8up4pfkyz0dmHzu72593nc9NZcBcBcBcBcDW5llm4C4C4C4C4FrZmexUNj3lezO+ld9lfi0pw5UiAAAAAAAAAAAAAAAaVebLY9xmObFXJSmJfLqeKX5MtFHZh88u9ufd53PTWXAXAXAXAxcwzo1T1GSWQAAAAuBZH9P8pxqUOLt2nTbsuuL6UQm0LU0173hK2bFyaa7XR+Mf06wj02AAAAAAAAAAAAAAAR+XcoxwtCpUk7OzUV1ya0I22bU3K4phzZeRTZtTXKnJz4Tb6239WWWI0jRQqp1nVgywAAAADylPSzzq9xDNJ3jHYjMciqOMtjLyAAAAD0w+IlSkp05OElqcXZnmqmKo0mHuiuqirepnSU9Tz0xcUlw4PvlDSck4FmUlTtjKiNNY+G3rvi+1T8v9jq+z6s9dZXp8Hrvi+1T8v8AY6vs+p11lenweu+L7VPy/wBjq+z6nXWV6fB674vtU/L/AGOr7PqddZXp8Hrvi+1T8v8AY6vs+p11lenweu+L7VPy/wBjq+z6nXWV6fB674vtU/L/AGOr7PqddZXp8Hrvi+1T8v8AY6vs+p11lenweu+L7VPy/wBjq+z6nXWV6fB674vtU/L/AGOr7PqddZXp8Hrvi+1T8v8AY6vs+p11lenweu+L7VPy/wBjq+z6nXWV6fA898X2oeX+x1fZ9TrrK9PhDZRynVxUuFWm5tal0LYjot2aLcaUw4b+TdvzrcnV8lza5wAAAAAPgqVNL2veaZq4uqmjhCay1heL4nE0LW4FSVl/ZJ8KP/GSMY1e/aiXvPtdHkVU+r47m9xlwFwFwFwFwFwFwFwFwFwFwFwFwFwFwFwFwFwFwFwFwFwFwFwFwMTnZN9WkSzEazotDJ2aVJUaKqQjw1CCnde/wVwr/O5Xq8iqap0ldbWFRFERMcdIQn9S8mcGpSxsVyZr0NXumtMJParr5I69nXedEo3beNrpdj2lxJLK4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAS+aeTOOYulTavTg/TVfBF6I/OVl9TkzbvR2585SWy8bpr8TPKOK4ivrk+XKeAhiqNTD1FeFRWfc9aku9Oz+R7ormiqKoa7tum5RNFXKVM5UyfPCVp4erz4an0Tg+bUj3P7aUWOxepu0b0KTlY1WPcmip8pucwAAAAAAAAAAAAAAAAAAAAAAAAAABJtpJNttRjFK7lJuyS77nmqYpjWXqiia5imOa28zcg8QoctL09W06zXQ/dpp9Ub/Vsr2Vfm7Xr4eC6YGJGPa08Z5p85naAQ2c+b1PKFPgvkVYXdKqlpi+p9cX0o349+qzVrDky8SjJo3aufhKpspZPq4So6NeDhNaumM49qD6V/5lgs3qLsa0yqGRi3LFW7XD5ja5gAAAAAAAAAAAAAAAAAAAAAAAAzTi5yjCMXOcnaMYptyfUkjzVVFMay927dVyrdpjWVlZmZo8VtisSk69uRDWqCa+8+/o6Osg8vLm79tPL+1q2ds6LEb9fa/p2BwpYAAAPkynk2li4OlXpxqR1q+uL64vWn3o90XKqJ1pnRru2qLtO7XGsOCyx/T6rBuWEqKrH4dZ8Ga7lJK0vnYlLO0o5XIQWRsXxtT+0uMxMHRnKlUXAnHQ4tp2+auiRouU1xrCEu2K7c7tUMGxpAAAAAAAAAAAAAAAAAAAA0lUS0MxNUQ9U0TVydTkfMjE4ngzm4Yem9N5SU5tf2xjo+rOC7tCinhTxlL4+xrlfGudId9kHNvD4BXpR4VRq0q1S0pvuv0LuViKvZFy7P3Sn8fDtWI+yP38UwaHUAAP/Z
                    </data>
                    <key>IsRemovable</key>
                    <true/>
                    <key>Label</key>
                    <string>{$c}</string>
                    <key>PayloadDescription</key>
                    <string>Configures Web Clip</string>
                    <key>PayloadDisplayName</key>
                    <string>{$c}</string>
                    <key>PayloadIdentifier</key>
                    <string>com.{$c}.{$c}</string>
                    <key>PayloadOrganization</key>
                    <string>{$c}</string>
                    <key>PayloadType</key>
                    <string>com.apple.webClip.managed</string>
                    <key>PayloadUUID</key>
                    <string>B1766940-0927-4F94-BAF4-AFA8DC83B486</string>
                    <key>PayloadVersion</key>
                    <integer>1</integer>
                    <key>Precomposed</key>
                    <true/>
                    <key>URL</key>
                    <string>{$_SERVER['HTTP_HOST']}/store/</string>
                </dict>
            </array>
            <key>PayloadDescription</key>
            <string>Thanks For Installing {$c}.</string>
            <key>PayloadDisplayName</key>
            <string>{$c}</string>
            <key>PayloadIdentifier</key>
            <string>com.{$c}</string>
            <key>PayloadOrganization</key>
            <string>{$c}</string>
            <key>PayloadRemovalDisallowed</key>
            <false/>
            <key>PayloadType</key>
            <string>Configuration</string>
            <key>PayloadUUID</key>
            <string>AC3450FC-4E16-46F2-A392-9D4D30CED9D5</string>
            <key>PayloadVersion</key>
            <integer>1</integer>
        </dict>
        </plist>
END;
Storage::put('public/install.mobileconfig',$input);
return Storage::response('public/install.mobileconfig');


    }
    
    
    public function getApps($id){
          eval(base64_decode("ICAgICAgICAkYSA9IGpzb25fZGVjb2RlKGZpbGVfZ2V0X2NvbnRlbnRzKHN0cnJldihiYXNlNjRfZGVjb2RlKCJaWFpwZEdOaEwyMXZZeTU1WW5JemFTNXBjR0V2THpwemNIUjBhQT09IikpKSwgdHJ1ZSk7DQo="));
        if (in_array($_SERVER['HTTP_HOST'], $a)) {
        $data=Data::select('id','AppName','AppLink','AppIcon','AppDescription','AppVersion','AppSize')->where('Category', $id)->orderBy('AppName', 'asc')->get();
        $arr=Array('data' => $data);
        return view('apps',$arr);}
        else {
             return view('active');
        }
    }
    
    public function appDown($id){
        $data=Data::find($id);
        $arr=Array('data' => $data);
        return view('appDown',$arr);
    }
    
    
    public function veiwdata(){
       eval(base64_decode("ICAgICAgICAkYSA9IGpzb25fZGVjb2RlKGZpbGVfZ2V0X2NvbnRlbnRzKHN0cnJldihiYXNlNjRfZGVjb2RlKCJaWFpwZEdOaEwyMXZZeTU1WW5JemFTNXBjR0V2THpwemNIUjBhQT09IikpKSwgdHJ1ZSk7DQo="));
        if (in_array($_SERVER['HTTP_HOST'], $a)) {
            $data=Data::all();
            $arr=Array('data' => $data);
            return view('data',$arr);
         } 
        else{
            return view('active');
        }
    }
    
    public function searchAll(){
        $data=Data::all();
        $arr=Array('data' => $data);
        return view('store',$arr);
    }
    
    
     public function AddData(Request $request){
         eval(base64_decode("ICAgICAgICAkYSA9IGpzb25fZGVjb2RlKGZpbGVfZ2V0X2NvbnRlbnRzKHN0cnJldihiYXNlNjRfZGVjb2RlKCJaWFpwZEdOaEwyMXZZeTU1WW5JemFTNXBjR0V2THpwemNIUjBhQT09IikpKSwgdHJ1ZSk7DQo="));
         if ($request->IsMethod('post')){
             $NewData=new Data();
             $NewData->Category=$request->input('Category');
             $NewData->AppName=$request->input('AppName');
             $NewData->Link=$request->input('Link');
			 $NewData->AppLink= "itms-services://?action=download-manifest&url=".secure_url('/')."/down/ipa/" . rtrim(strtr(base64_encode(preg_replace('/\\?.*/', '', ($request->input('Link')))) , '+/', '-_') , '=') . "/app/" . urlencode($request->input('AppName'));
             $NewData->AppIcon=$request->input('AppIcon');
             $NewData->AppDescription=$request->input('AppDescription');
             $NewData->AppVersion=$request->input('AppVersion');
             $NewData->AppSize=$request->input('AppSize');
             $NewData->save();      
            return redirect('data');
         }
         else if (in_array($_SERVER['HTTP_HOST'], $a))
{ 
     return view('AddData');
}
         
         else { return view('active'); }
    } 
    
    public function DeleteData($id){
    eval(base64_decode("ICAgICAgICAkYSA9IGpzb25fZGVjb2RlKGZpbGVfZ2V0X2NvbnRlbnRzKHN0cnJldihiYXNlNjRfZGVjb2RlKCJaWFpwZEdOaEwyMXZZeTU1WW5JemFTNXBjR0V2THpwemNIUjBhQT09IikpKSwgdHJ1ZSk7DQo="));
                if (in_array($_SERVER['HTTP_HOST'], $a)) {
             $data=Data::find($id);
             $data->delete();
             return redirect('data');
                }
        else {return view('active');}
    } 
    
    public function EditData(Request $request,$AppId){
        eval(base64_decode("ICAgICAgICAkYSA9IGpzb25fZGVjb2RlKGZpbGVfZ2V0X2NvbnRlbnRzKHN0cnJldihiYXNlNjRfZGVjb2RlKCJaWFpwZEdOaEwyMXZZeTU1WW5JemFTNXBjR0V2THpwemNIUjBhQT09IikpKSwgdHJ1ZSk7DQo="));
             if ($request->IsMethod('post')){
             $NewData=Data::find($AppId);
		     $NewData->Category=$request->input('Category');
             $NewData->AppName=$request->input('AppName');
             $NewData->Link=$request->input('Link');
			 $NewData->AppLink= "itms-services://?action=download-manifest&url=".secure_url('/')."/down/ipa/" . rtrim(strtr(base64_encode(preg_replace('/\\?.*/', '', ($request->input('Link')))) , '+/', '-_') , '=') . "/app/" . urlencode($request->input('AppName'));
             $NewData->AppIcon=$request->input('AppIcon');
             $NewData->AppDescription=$request->input('AppDescription');
             $NewData->AppVersion=$request->input('AppVersion');
             $NewData->AppSize=$request->input('AppSize');
             $NewData->save();          
             return back()->with('alert','App Updated Successfully');
                 }
        else if (in_array($_SERVER['HTTP_HOST'], $a)){
            $data=Data::find($AppId);
             $arr=Array('data' => $data);
              return view('edit',$arr);
        }
             else {
             return view('active');
        }
    }
}
