<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Data;

class DataController extends Controller
{
    public function download($ipa=null,$app=null) 
    {
        header('Content-Type: text/xml;charset=UTF-8');

$z = base64_decode($ipa) ;
$x = urldecode ($app);
$c = config('app.name');
        
$input = <<<END
<?xml version="1.0" encoding="UTF-8"?>
						<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
						<plist version="1.0">
						<dict>
						   <key>items</key>
						   <array>
						       <dict>
						           <key>assets</key>
						           <array>
						               <dict>
						                   <key>kind</key>
						                   <string>software-package</string>
						                   <key>url</key>
						                   <string>{$z}</string>
						               </dict>
						               <dict>
						                   <key>kind</key>
						                   <string>display-image</string>
						                   <key>needs-shine</key>
						                   <true/>
						                   <key>url</key>
						                   <string>https://i.imgur.com/3WYFVmD.png</string>
						                </dict>
										<dict>
										<key>kind</key>
										<string>full-size-image</string>
										<key>needs-shine</key>
										<true/>
										<key>url</key>
										<string>https://i.imgur.com/3WYFVmD.png</string>
										</dict>
						           </array>
						           <key>metadata</key>
						           <dict>
						               <key>bundle-identifier</key>
						               <string>com.i3rby.{$x}</string>
						               <key>bundle-version</key>
						               <string>1.3.5</string>
						               <key>kind</key>
						               <string>software</string>
						               <key>title</key>
									   <string>   
									   
⚡{$x}⚡
⚡{$c}⚡
 			  </string>

						           </dict>
						       </dict>
						   </array>
						</dict>
						</plist>
END;

return $input;


    }
    
    public function appsList($id){
        $data=Data::select('id','AppName','AppLink','AppIcon','AppDescription','AppVersion','AppSize')->where('Category', $id)->orderBy('AppName', 'asc')->get();
        $arr=Array('data' => $data);
        return view('appsList',$arr);
    }
    
     public function test($id){
        $data=Data::select('id','AppName','AppLink','AppIcon','AppDescription','AppVersion','AppSize')->where('Category', $id)->get()->random(2);
        $arr=Array('data' => $data);
        return $arr;
    }
    
    
    public function getApps($id){
        $data=Data::select('id','AppName','AppLink','AppIcon','AppDescription','AppVersion','AppSize')->where('Category', $id)->orderBy('AppName', 'asc')->get();
        $arr=Array('data' => $data);
        return view('apps',$arr);
    }
    
    public function appDown($id){
        $data=Data::find($id);
        $arr=Array('data' => $data);
        return view('appDown',$arr);
    }
    
    
    public function veiwdata(){
        
        
            $data=Data::all();
            $arr=Array('data' => $data);
            return view('data',$arr);
        
        
    }
    
    public function searchAll(){
        $data=Data::all();
        $arr=Array('data' => $data);
        return view('store',$arr);
    }
    
     public function veiwdataId($id){
        $data=Data::find($id);
        $arr=Array('data' => $data);
        return view('data',$arr);
    }
    
     public function AddData(Request $request){
         if ($request->IsMethod('post')){
             $NewData=new Data();
             $NewData->Category=$request->input('Category');
             $NewData->AppName=$request->input('AppName');
             $NewData->Link=$request->input('Link');
			 $NewData->AppLink= "itms-services://?action=download-manifest&url=".secure_url('/')."/down/ipa/" . rtrim(strtr(base64_encode(preg_replace('/\\?.*/', '', ($request->input('Link')))) , '+/', '-_') , '=') . "/app/" . urlencode($request->input('AppName'));
             $NewData->AppIcon=$request->input('AppIcon');
             $NewData->AppDescription=$request->input('AppDescription');
             $NewData->AppVersion=$request->input('AppVersion');
             $NewData->AppSize=$request->input('AppSize');
             $NewData->save();      
            return redirect('data');
         }
         else { return view('AddData');}
    } 
    
    public function DeleteData($id){
    
             $data=Data::find($id);
             $data->delete();
             return redirect('data');
    } 
    
    public function EditData(Request $request,$AppId){
             if ($request->IsMethod('post')){
             $NewData=Data::find($AppId);
		     $NewData->Category=$request->input('Category');
             $NewData->AppName=$request->input('AppName');
             $NewData->Link=$request->input('Link');
			 $NewData->AppLink= "itms-services://?action=download-manifest&url=".secure_url('/')."/down/ipa/" . rtrim(strtr(base64_encode(preg_replace('/\\?.*/', '', ($request->input('Link')))) , '+/', '-_') , '=') . "/app/" . urlencode($request->input('AppName'));
             $NewData->AppIcon=$request->input('AppIcon');
             $NewData->AppDescription=$request->input('AppDescription');
             $NewData->AppVersion=$request->input('AppVersion');
             $NewData->AppSize=$request->input('AppSize');
             $NewData->save();          
             return back()->with('alert','App Updated Successfully');
                 }
             else {
             $data=Data::find($AppId);
             $arr=Array('data' => $data);
              return view('edit',$arr);
        }
    }
}
