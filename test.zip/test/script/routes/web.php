<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Auth::routes();


// Authentication Routes...
$this->get('loginadmincp', 'Auth\LoginController@showLoginForm')->name('login');
$this->post('loginadmincp', 'Auth\LoginController@login');
$this->post('logout', 'Auth\LoginController@logout')->name('logout');

// Registration Routes...
$this->get('newadminreg', 'Auth\RegisterController@showRegistrationForm')->name('register');
$this->post('newadminreg', 'Auth\RegisterController@register');

// Password Reset Routes...
$this->get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('password.request');
$this->post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');
$this->get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset');
$this->post('password/reset', 'Auth\ResetPasswordController@reset')->name('password.update');

// Email Verification Routes...
$this->get('email/verify', 'Auth\VerificationController@show')->name('verification.notice');
$this->get('email/verify/{id}', 'Auth\VerificationController@verify')->name('verification.verify');
$this->get('email/resend', 'Auth\VerificationController@resend')->name('verification.resend');



Route::get('/changePassword','HomeController@showChangePasswordForm');
Route::post('/changePassword','HomeController@changePassword')->name('changePassword');

Route::get('/data', 'DataController@veiwdata')->middleware('auth');
Route::get('/add', 'DataController@AddData')->middleware('auth');
Route::post('/add', 'DataController@AddData')->middleware('auth');
Route::get('section/delete/{AppId}', 'DataController@DeleteData')->middleware('auth');
Route::get('section/edit/{AppId}', 'DataController@EditData')->middleware('auth');
Route::post('section/edit/{AppId}', 'DataController@EditData')->middleware('auth');


Route::get('store', 'DataController@searchAll');
Route::get('installconfig', 'DataController@installconfig');

Route::get('section/{id}', 'DataController@getApps')->middleware('auth');



Route::get('cat/{id}', 'DataController@appsList');
Route::get('appdown/{id}', 'DataController@appDown');
Route::get('test/{id}', 'DataController@test');



Route::get('down/ipa/{ipa}/app/{app}', 'DataController@download');
Route::get('down', function () {
    return 'Nothing here !';
});

