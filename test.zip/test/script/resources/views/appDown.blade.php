<div class="page">
    <div class="navbar">
        <div class="navbar-inner sliding">
            <div class="left">
                <a href="#" class="link back">
                    <i class="icon icon-back"></i>
                    <span class="ios-only">Back</span>
                </a>
            </div>
            <div class="title">{{ $data->AppName }}</div>
            <div class="right">
                <a href="javascript:window.location.reload(true)" class="f7-icons">reload</a>
    </div>
        </div>
    </div>

    <div class="page-content">


        <div class="list media-list">
            <ul>
                <li class="media-item">
                        <div class="item-content">
                            <div class="item-media">
                                <img src="{{ $data->AppIcon }}" class="appicon elevation-5"></div>
                            <div class="item-inner">
                                <div class="item-title-row">
                                    <div class="item-title">{{ $data->AppName }}</div>
      									
									<a href="{{ $data->AppLink }}" class="button button-round button-fill button-raised color-green external">Get <i class="icon f7-icons color-white">cloud_download</i></a>
                                </div>
                                          <div class="item-subtitle">{{ $data->Category }}</div>
                            </div>
                        </div>
                    </li>
            </ul>
        </div>
        
        <div class="block-title">About {{ $data->AppName }}</div>
        <div class="block block-strong"><pre> {{ $data->AppDescription }}</pre></div>

<div class="list">
<ul>
<li>
<div class="item-content">
<div class="item-inner">
<div class="item-title">Version</div>
<div class="item-after">v{{ $data->AppVersion }}</div>
</div>
</div>
</li>
<li>
<div class="item-content">
<div class="item-inner">
<div class="item-title">Size</div>
<div class="item-after">{{ $data->AppSize }}</div>
</div>
</div>
</li>
</ul>
</div>
    </div>
        
</div>
