@extends('layouts.app')
@section('content')

    <!-- Page Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
		
		
	   
          <table class="table">
  <thead>
    <tr>
      <th scope="col">Category</th>
      <th scope="col">App Name</th>
      <th scope="col">App Version</th>
      <th scope="col">App Size</th>
    </tr>
  </thead>
  <tbody>
        @foreach ($data as $dataId )
    <tr>
      <td>{{ $dataId->Category }} </td>
      <td>{{ $dataId->AppName }} </td>
      <td>{{ $dataId->AppVersion }}  </td>
      <td>{{ $dataId->AppSize }}  </td>
       <td>
         <a href="section/delete/{{$dataId->id}}" class="btn btn-danger" >Delete</a>
         <a href="section/edit/{{$dataId->id}}" class="btn btn-info" >Edit</a>
      </td>
    </tr>
       @endforeach
  </tbody>
</table>     
            
            
            
            
        </div>
      </div>
    </div>

     @endsection
