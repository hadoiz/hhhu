<?php
use Illuminate\Support\Facades\Input;

header('Content-Type: text/xml;charset=UTF-8');
//$file = $_GET["app"].'.plist';
//header('Content-Disposition: attachment; filename="'.$file.'"');
$z = base64_decode($ipa) ;
$x = urldecode ($app);
$c = $c = config('app.name');
$input = <<<END
<?xml version="1.0" encoding="UTF-8"?>
						<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
						<plist version="1.0">
						<dict>
						   <key>items</key>
						   <array>
						       <dict>
						           <key>assets</key>
						           <array>
						               <dict>
						                   <key>kind</key>
						                   <string>software-package</string>
						                   <key>url</key>
						                   <string>{$z}</string>
						               </dict>
						               <dict>
						                   <key>kind</key>
						                   <string>display-image</string>
						                   <key>needs-shine</key>
						                   <true/>
						                   <key>url</key>
						                   <string>https://i.imgur.com/3WYFVmD.png</string>
						                </dict>
										<dict>
										<key>kind</key>
										<string>full-size-image</string>
										<key>needs-shine</key>
										<true/>
										<key>url</key>
										<string>https://i.imgur.com/3WYFVmD.png</string>
										</dict>
						           </array>
						           <key>metadata</key>
						           <dict>
						               <key>bundle-identifier</key>
						               <string>com.i3rby.{$x}</string>
						               <key>bundle-version</key>
						               <string>1.3.5</string>
						               <key>kind</key>
						               <string>software</string>
						               <key>title</key>
									   <string>   
									   
⚡{$x}⚡
{$c}
 
💘متجر ايفون بالعربي💘

Twitter: @iphone3rby
Facebook: @iphone3rby
Telegram: @iphonearabic
			  </string>

						           </dict>
						       </dict>
						   </array>
						</dict>
						</plist>
END;

$xml = new SimpleXMLElement($input);
//$xml->dict->array->dict->array->dict->string[1] = $_GET["ipa"];
echo  $input;
//$output = $xml->asXML($file);


