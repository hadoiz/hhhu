<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Security-Policy"
        content="default-src * 'self' 'unsafe-inline' 'unsafe-eval' data: gap: content:">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui, viewport-fit=cover">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="theme-color" content="#2196f3">
    <meta name="format-detection" content="telephone=no">
    <meta name="msapplication-tap-highlight" content="no">
    <title><?php echo e(config('app.name')); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('x/framework7/css/framework7.bundle.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('x/css/icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('x/css/app.css')); ?>">
</head>

<body>
    <div id="app">
        <!-- Status bar overlay for fullscreen mode-->
        <div class="statusbar"></div>
        <!-- Left panel with cover effect-->
        <div class="panel panel-left panel-cover theme-dark">
            <div class="view">
                <div class="page">
                    <div class="navbar">
                        <div class="navbar-inner">
                            <div class="title">Left Panel</div>
                        </div>
                    </div>
                    <div class="page-content">
                        <div class="block">Left panel content goes here</div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Right panel with reveal effect-->
        <div class="panel panel-right panel-reveal theme-dark">
            <div class="view">
                <div class="page">
                    <div class="navbar">
                        <div class="navbar-inner">
                            <div class="title">Right Panel</div>
                        </div>
                    </div>
                    <div class="page-content">
                        <div class="block">Right panel content goes here</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Views/Tabs container -->
        <div class="views tabs safe-areas">
            <!-- Tabbar for switching views-tabs -->
            <div class="toolbar tabbar-labels toolbar-bottom">
                <div class="toolbar-inner">
                    <a href="#view-home" class="tab-link tab-link-active">
                        <i class="icon f7-icons ios-only">home</i>
                        <i class="icon f7-icons ios-only icon-ios-fill">home_fill</i>
                        <i class="icon material-icons md-only">home</i>
                        <span class="tabbar-label">Home</span>
                    </a>
                    <a href="#view-search" class="tab-link">
                        <i class="icon f7-icons ios-only">search</i>
                        <i class="icon f7-icons ios-only icon-ios-fill">search</i>
                        <i class="icon material-icons md-only">search</i>
                        <span class="tabbar-label">Search</span>
                    </a>
                </div>
            </div>


            <!-- Your main view/tab, should have "view-main" class. It also has "tab-active" class -->
            <div id="view-home" class="view view-main tab tab-active">
                <!-- Page, data-name contains page name which can be used in page callbacks -->
                <div class="page" data-name="home">
                    <!-- Top Navbar -->
                    <div class="navbar">
                        <!-- Additional "navbar-inner-large" class on navbar-inner -->
                        <div class="navbar-inner navbar-inner-large sliding">
                            <div class="right">
                                <a href="javascript:window.location.reload(true)" class="f7-icons">reload</a>
                            </div>
                            <div class="left">
                                <script>
                                    var today = new Date();
                                    var dd = String(today.getDate()).padStart(2, '0');
                                    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
                                    var yyyy = today.getFullYear();

                                    today = mm + '/' + dd + '/' + yyyy;
                                    document.write(today);
                                </script>
                            </div>
                            <div class="title-large">
                                <div class="title-large-text">Home</div>
                            </div>
                        </div>
                    </div>

                    <!-- Scrollable page content-->
                    <div class="page-content">

                        <h1 class="header"><?php echo e(config('app.name')); ?></h1>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- tweakdoor -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4420332636058530"
     data-ad-slot="6519622496"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

                        <div class="block-title">Categories</div>

                        <div class="list inset media-list">
                            <ul>
                                <li class="media-item"><a href="/tweaked/" class="item-link">
                                        <div class="item-content">
                                            <div class="item-media">
                                                <div><img src="<?php echo e(asset('x/img/Tweaked.png')); ?>" class="appiconx"></div>
                                            </div>
                                            <div class="item-inner">
                                                <div class="item-title-row">
                                                    <div class="item-title">Tweaked Apps</div>
                                                </div>
                                                <div class="item-text">Modified Apps</div>
                                            </div>
                                        </div>
                                    </a></li>
                                <li class="media-item"><a href="/apps/" class="item-link">
                                        <div class="item-content">
                                            <div class="item-media">
                                                <div><img src="<?php echo e(asset('x/img/AppStore.png')); ?>" class="appiconx">
                                                </div>
                                            </div>
                                            <div class="item-inner">
                                                <div class="item-title-row">
                                                    <div class="item-title">Apps</div>
                                                </div>
                                                <div class="item-text">Paid Apps</div>
                                            </div>
                                        </div>
                                    </a></li>

                                <li class="media-item"><a href="/games/" class="item-link">
                                        <div class="item-content">
                                            <div class="item-media">
                                                <div><img src="<?php echo e(asset('x/img/Games.png')); ?>" class="appiconx"></div>
                                            </div>
                                            <div class="item-inner">
                                                <div class="item-title-row">
                                                    <div class="item-title">Games</div>
                                                </div>
                                                <div class="item-text">Paid Games</div>
                                            </div>
                                        </div>
                                    </a></li>
                                <li class="media-item"><a href="/tools/" class="item-link">
                                        <div class="item-content">
                                            <div class="item-media">
                                                <div><img src="<?php echo e(asset('x/img/Utilities.png')); ?>" class="appiconx">
                                                </div>
                                            </div>
                                            <div class="item-inner">
                                                <div class="item-title-row">
                                                    <div class="item-title">Tools</div>
                                                </div>
                                                <div class="item-text">Tools Apps</div>
                                            </div>
                                        </div>
                                    </a></li>
                            </ul>
                        </div>


                    </div>
                </div>
            </div>

            <!-- Catalog View -->
            <div id="view-catalog" class="view tab">
                <div class="page">
                    <div class="navbar">
                        <div class="navbar-inner sliding">
                            <div class="left">
                                <a href="#" class="link back">
                                    <i class="icon icon-back"></i>
                                    <span class="ios-only">Back</span>
                                </a>
                            </div>
                            <div class="right">
                                <a href="javascript:window.location.reload(true)" class="f7-icons">reload</a>
                            </div>
                            <div class="title-large">
                                <div class="title-large-text"><?php echo e(Route::current()->parameter('id')); ?></div>
                            </div>
                            <div class="subnavbar">
                                <form data-search-in=".item-title" data-search-container=".list"
                                    class="searchbar searchbar-init">
                                    <div class="searchbar-inner">
                                        <div class="searchbar-input-wrap">
                                            <input type="search" placeholder="Search">
                                            <i class="searchbar-icon"></i>
                                            <span class="input-clear-button"></span>
                                        </div>
                                        <span class="searchbar-disable-button if-not-aurora">Cancel</span>
                                    </div>
                                </form>
                            </div>

                        </div>

                    </div>


                    <div class="page-content">
                        <div class="searchbar-backdrop"></div>


                        <div class="list media-list inset searchbar-found">
                            <ul>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="media-item"><a href="/appdown/<?php echo e($dataId->id); ?>" class="item-link">
                                        <div class="item-content">
                                            <div class="item-media">
                                                <img src="<?php echo e($dataId->AppIcon); ?>" class="appiconx elevation-5"></div>
                                            <div class="item-inner">
                                                <div class="item-title-row">
                                                    <div class="item-title"><?php echo e($dataId->AppName); ?></div>
                                                </div>
                                                <div class="chip" v-if="8.4.79">
                                                    <div class="chip-media bg-color-blue"><i
                                                            class="icon f7-icons">gear</i></div>
                                                    <div class="chip-label"><?php echo e($dataId->AppVersion); ?></div>
                                                </div>
                                                <div class="chip" v-if="64.65MB">
                                                    <div class="chip-media bg-color-blue"><i
                                                            class="icon f7-icons">download</i></div>
                                                    <div class="chip-label"><?php echo e($dataId->AppSize); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    </a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                        <div class="block searchbar-not-found">
                            <div class="block-inner">Nothing found</div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="view-search" class="view tab">
                <div class="page">
                    <div class="navbar">
                        <div class="navbar-inner sliding">
                            <div class="title-large">
                                <div class="title-large-text">Search</div>
                            </div>
                            <div class="subnavbar">
                                <form data-search-in=".item-title" data-search-container=".list"
                                    class="searchbar searchbar-init">
                                    <div class="searchbar-inner">
                                        <div class="searchbar-input-wrap">
                                            <input type="search" placeholder="Search">
                                            <i class="searchbar-icon"></i>
                                            <span class="input-clear-button"></span>
                                        </div>
                                        <span class="searchbar-disable-button if-not-aurora">Cancel</span>
                                    </div>
                                </form>
                            </div>

                        </div>

                    </div>


                    <div class="page-content">
                        <div class="searchbar-backdrop"></div>


                        <div class="list media-list inset searchbar-found">
                            <ul>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="media-item"><a href="/appdown/<?php echo e($dataId->id); ?>" class="item-link">
                                        <div class="item-content">
                                            <div class="item-media">
                                                <img src="<?php echo e($dataId->AppIcon); ?>" class="appiconx elevation-5"></div>
                                            <div class="item-inner">
                                                <div class="item-title-row">
                                                    <div class="item-title"><?php echo e($dataId->AppName); ?></div>
                                                </div>
                                                <div class="chip">
                                                    <div class="chip-media bg-color-blue"><i
                                                            class="icon f7-icons">gear</i></div>
                                                    <div class="chip-label"><?php echo e($dataId->AppVersion); ?></div>
                                                </div>
                                                <div class="chip">
                                                    <div class="chip-media bg-color-blue"><i
                                                            class="icon f7-icons">download</i></div>
                                                    <div class="chip-label"><?php echo e($dataId->AppSize); ?></div>
                                                </div>
                                                <div class="chip">
                                                    <div class="chip-media bg-color-blue"><i
                                                            class="icon f7-icons">data</i></div>
                                                    <div class="chip-label"><?php echo e($dataId->Category); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    </a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                        <div class="block searchbar-not-found">
                            <div class="block-inner">Nothing found</div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>


    <!-- Framework7 library -->
    <script src="<?php echo e(asset('x/framework7/js/framework7.bundle.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/inobounce/0.1.6/inobounce.min.js"></script>

    <!-- App routes -->
    <script src="<?php echo e(asset('x/js/routes.js')); ?>"></script>

    <!-- Your custom app scripts -->
    <script src="<?php echo e(asset('x/js/app.js')); ?>"></script>
</body>

</html>