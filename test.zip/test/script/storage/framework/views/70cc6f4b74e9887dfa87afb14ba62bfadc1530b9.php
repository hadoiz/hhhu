
<?php $__env->startSection('content'); ?>

    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
        <form action="add" method="post">
            <?php echo e(csrf_field()); ?>

			
             Category        : <br>
            <select class="form-control" name="Category">
           <option value="tweaked">Tweaked</option>
		   <option value="apps">Apps</option>
           <option value="tools">Tools</option>
           <option value="games">Games</option>
           </select>            <br>
		   
            <br>
            App Name           :  <input class="form-control" style="text-transform: capitalize;" type="text" name="AppName" placeholder="App Name">
            <br>
            IPA Link	       :  <input class="form-control" type="text" name="Link" placeholder="IPA Link">
            <br>
            App Icon	       :  <input class="form-control" type="text" name="AppIcon" placeholder="App Icon">
            <br>
            App Description	   :  <textarea class="form-control"  name="AppDescription" rows="5" placeholder="App Description" ></textarea>
            <br>
            App Version	       :  <input class="form-control" style="text-transform: capitalize;" type="text" name="AppVersion" placeholder="App Version">
            <br>
            App Size	       :  <input class="form-control" style="text-transform: capitalize;" type="text" name="AppSize" placeholder="App Size">
            <br> 
            
           
			  <button type="submit" value="add" class="btn btn-default">Add</button>

        </form>
		   </div>
    </div>
  </div>
           <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>