<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Control Panel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
	
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Control Panel')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                    <?php if(Auth::guest()): ?>
                    <?php else: ?>
					<li class="nav-link <?php echo e(Request::segment(1) === 'data' ? 'active' : null); ?>" role="home"><a href="<?php echo e(url('data' )); ?>">ALL</a></li>
					<li class="nav-link <?php echo e(Request::segment(1) === 'tweaked' ? 'active' : null); ?>" role="tweaked"><a href="<?php echo e(url('section/tweaked' )); ?>">Tweaked</a></li>
					<li class="nav-link <?php echo e(Request::segment(1) === 'apps' ? 'active' : null); ?>" role="apps"><a href="<?php echo e(url('section/apps' )); ?>">Apps</a></li>
					<li class="nav-link <?php echo e(Request::segment(1) === 'tools' ? 'active' : null); ?>" role="tools"><a href="<?php echo e(url('section/tools' )); ?>">Tools</a></li>
					<li class="nav-link <?php echo e(Request::segment(1) === 'games' ? 'active' : null); ?>" role="games"><a href="<?php echo e(url('section/games' )); ?>">Games</a></li>
                    <li class="nav-link <?php echo e(Request::segment(1) === 'add' ? 'active' : null); ?>" role="add"><a href="<?php echo e(url('add' )); ?>">Add</a></li>        
					<?php endif; ?>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li><a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></li>
                        <?php else: ?>

                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>
									
									<a class="dropdown-item" href="<?php echo e(route('changePassword')); ?>">
                                        <?php echo e(__('Change Password')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
									
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

	</div>
        <main class="py-4">
		<div class="col-lg-12 text-center">
       <?php if(session('alert')): ?>
    <div class="alert alert-success">
        <?php echo e(session('alert')); ?>

    </div>
       <?php endif; ?>
    </div>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
		
    </div>
</body>
</html>
