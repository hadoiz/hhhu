<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo e(config('app.name')); ?> : Home</title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="assets/images/favicon.ico"/>
    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="<?php echo e(asset('z/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Slick slider -->
    <link href="<?php echo e(asset('z/css/slick.css')); ?>" rel="stylesheet">
    <!-- Theme color -->
    <link id="switcher" href="<?php echo e(asset('z/css/theme-color/default-theme.css')); ?>" rel="stylesheet">


    <!-- Main Style -->
    <link href="<?php echo e(asset('z/style.css')); ?>" rel="stylesheet">

    <!-- Fonts -->

    <!-- Open Sans for body and title font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700,800" rel="stylesheet">
 
 
	
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>

  
  	
  	<!-- Start Header -->
	<header id="mu-header" class="" role="banner">
		<div class="mu-header-overlay">
			<div class="container">
				<div class="mu-header-area">

					<!-- Start Logo -->
					<div class="mu-logo-area">
						<!-- text based logo -->
						<a class="mu-logo" href="#"><?php echo e(config('app.name')); ?></a>
					</div>
					<!-- End Logo -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- tweakdoor -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4420332636058530"
     data-ad-slot="6519622496"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
					<!-- Start header featured area -->
					<div class="mu-header-featured-area">
						<div class="mu-header-featured-img">
							<img src="<?php echo e(asset('z/images/iphone.png')); ?>" alt="iphone image">
						</div>
						<div class="mu-header-featured-content">
							<h1>Welcome To <span><?php echo e(config('app.name')); ?></span></h1>
							<img src="<?php echo e(asset('https://tweakdoor.com/files/img/Jok3rHelper.png')); ?>" alt="Tweakdoor">
							<p>The Best IOS Alternative Appstore</p>
							<div class="mu-app-download-area">
								<h4>Download The App</h4>
								<a class="mu-apple-btn" href="installconfig"><i class="fa fa-apple"></i><span>Download</span></a>
							</div>

						</div>
					</div>
					<!-- End header featured area -->

				</div>
			</div>
		</div>
	</header>
	<!-- End Header -->

	
	
	<!-- Start main content -->
		
	<main role="main">
		

		
	</main>
	
	<!-- End main content -->	
			
			
	<!-- Start footer -->
	<footer id="mu-footer" role="contentinfo">
			<div class="container">
				<div class="mu-footer-area">
					<p class="mu-copy-right">&copy; <?php echo e(config('app.name')); ?> . All right reserved.</p>
				</div>
			</div>

	</footer>
	<!-- End footer -->

	
	
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <!-- Bootstrap -->
    <script src="<?php echo e(asset('z/js/bootstrap.min.js')); ?>"></script>
	<!-- Slick slider -->
    <script type="text/javascript" src="<?php echo e(asset('z/js/slick.min.js')); ?>"></script>
    <!-- Ajax contact form  -->
    <script type="text/javascript" src="<?php echo e(asset('z/js/app.js')); ?>"></script>
  
    
	
    <!-- Custom js -->
	<script type="text/javascript" src="<?php echo e(asset('z/js/custom.js')); ?>"></script>

	
	
    
  </body>
</html>