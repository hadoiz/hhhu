<div class="page">
    <div class="navbar">
        <div class="navbar-inner sliding">
            <div class="left">
                <a href="#" class="link back">
                    <i class="icon icon-back"></i>
                    <span class="ios-only">Back</span>
                </a>
            </div>
            <div class="right">
                <a href="javascript:window.location.reload(true)" class="f7-icons">reload</a>
    </div>
      <div class="title-large">
        <div class="title-large-text"><?php echo e(Route::current()->parameter('id')); ?></div>
      </div>
            <div class="subnavbar">
    <form  data-search-in=".item-title" data-search-container=".list" class="searchbar searchbar-init">
          <div class="searchbar-inner">
            <div class="searchbar-input-wrap">
              <input type="search" placeholder="Search">
              <i class="searchbar-icon"></i>
              <span class="input-clear-button"></span>
            </div>
            <span class="searchbar-disable-button if-not-aurora">Cancel</span>
          </div>
        </form>
      </div>
            
        </div>
        
    </div>
    

    <div class="page-content">
            <div class="searchbar-backdrop"></div>

        
        <div class="list media-list inset searchbar-found">
            <ul>
         <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="media-item"><a href="/appdown/<?php echo e($dataId->id); ?>" class="item-link">
                        <div class="item-content">
                            <div class="item-media">
                                <img  src="<?php echo e($dataId->AppIcon); ?>" class="appiconx elevation-5"></div>
                            <div class="item-inner">
                                <div class="item-title-row">
                                    <div class="item-title"><?php echo e($dataId->AppName); ?></div>
                                </div>
                                <div class="chip" v-if="8.4.79">
                                    <div class="chip-media bg-color-blue"><i class="icon f7-icons">gear</i></div>
                                    <div class="chip-label"><?php echo e($dataId->AppVersion); ?></div>
                                </div>
                                <div class="chip" v-if="64.65MB">
                                    <div class="chip-media bg-color-blue"><i class="icon f7-icons">download</i></div>
                                    <div class="chip-label"><?php echo e($dataId->AppSize); ?></div>
                                </div>
                            </div>
                        </div>
                    </a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

<div class="block searchbar-not-found">
      <div class="block-inner">Nothing found</div>
    </div>

    </div>
</div>
