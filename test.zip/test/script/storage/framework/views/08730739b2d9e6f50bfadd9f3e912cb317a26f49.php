
<?php $__env->startSection('content'); ?>

    <!-- Page Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
		
		
	   
          <table class="table">
  <thead>
    <tr>
      <th scope="col">Category</th>
      <th scope="col">App Name</th>
      <th scope="col">App Version</th>
      <th scope="col">App Size</th>
    </tr>
  </thead>
  <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($dataId->Category); ?> </td>
      <td><?php echo e($dataId->AppName); ?> </td>
      <td><?php echo e($dataId->AppVersion); ?>  </td>
      <td><?php echo e($dataId->AppSize); ?>  </td>
       <td>
         <a href="section/delete/<?php echo e($dataId->id); ?>" class="btn btn-danger" >Delete</a>
         <a href="section/edit/<?php echo e($dataId->id); ?>" class="btn btn-info" >Edit</a>
      </td>
    </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>     
            
            
            
            
        </div>
      </div>
    </div>

     <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>