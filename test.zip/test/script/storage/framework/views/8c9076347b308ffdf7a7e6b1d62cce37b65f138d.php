<?php $__env->startSection('content'); ?>

    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">

<form action="<?php echo e(\Request::url()); ?>" method="post">
  <?php echo e(csrf_field()); ?>

  
  
  <div class="form-group">
    <label  for="Category">Category:</label>
       <select  class="form-control" name="Category">
           <option selected ><?php echo e($data->Category); ?></option>
           <option value="tweaked">tweaked</option>
		   <option value="apps">apps</option>
           <option value="tools">tools</option>
           <option value="games">games</option>
           </select>       
  </div>
 
  

<div class="form-group">
 <label for="AppName">App Name:</label>
            <input type="text" style="text-transform: capitalize;" class="form-control" name="AppName" placeholder="App Name" value="<?php echo e($data->AppName); ?>">
		   </div>

<div class="form-group">
 <label for="AppLink">IPA Link:</label>
            <input type="text" class="form-control" name="Link" placeholder="IPA Link" value="<?php echo e($data->Link); ?>">
		   </div>
		   
 <div class="form-group">
 <label for="AppIcon">App Icon:</label>
            <input type="text" class="form-control" name="AppIcon" placeholder="App Icon" value="<?php echo e($data->AppIcon); ?>">
		   </div>

<div class="form-group">
 <label for="AppDescription">App Description:</label>
            <textarea class="form-control" name="AppDescription" rows="5" ><?php echo e($data->AppDescription); ?></textarea>
		  </div>
		   
		   
<div class="form-group">
 <label for="AppVersion">App Version:</label>
            <input type="text" style="text-transform: capitalize;" class="form-control" name="AppVersion" placeholder="App Version" value="<?php echo e($data->AppVersion); ?>">
		   </div>

		   
<div class="form-group">
 <label for="AppSize">App Size:</label>
            <input type="text" style="text-transform: capitalize;" class="form-control" name="AppSize" placeholder="App Size" value="<?php echo e($data->AppSize); ?>">
		   </div>
		  
 
 
  <button type="submit" class="btn btn-default">Update</button>
</form>

		
      
      </div>
    </div>
  </div>
           <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>